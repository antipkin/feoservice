--
-- PostgreSQL database dump
--

\restrict QzQomyhycbrzOubvcZNEOfP88EYY6lP8ibwTAHEy7NS4oj0JchWIauCyEzZIo1Z

-- Dumped from database version 15.19 (Debian 15.19-1.pgdg13+2)
-- Dumped by pg_dump version 15.19 (Debian 15.19-1.pgdg13+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.service_types DROP CONSTRAINT IF EXISTS fk_service_types_unit_id_units;
ALTER TABLE IF EXISTS ONLY public.service_types DROP CONSTRAINT IF EXISTS fk_service_types_category_id_service_categories;
ALTER TABLE IF EXISTS ONLY public.service_rates DROP CONSTRAINT IF EXISTS fk_service_rates_service_type_id_service_types;
ALTER TABLE IF EXISTS ONLY public.service_rates DROP CONSTRAINT IF EXISTS fk_service_rates_object_id_objects;
ALTER TABLE IF EXISTS ONLY public.service_pricing_settings DROP CONSTRAINT IF EXISTS fk_service_pricing_settings_service_type_id_service_types;
ALTER TABLE IF EXISTS ONLY public.service_pricing_settings DROP CONSTRAINT IF EXISTS fk_service_pricing_settings_object_id_objects;
ALTER TABLE IF EXISTS ONLY public.resource_rates DROP CONSTRAINT IF EXISTS fk_resource_rates_resource_id_resources;
ALTER TABLE IF EXISTS ONLY public.resource_norms DROP CONSTRAINT IF EXISTS fk_resource_norms_service_type_id_service_types;
ALTER TABLE IF EXISTS ONLY public.resource_norms DROP CONSTRAINT IF EXISTS fk_resource_norms_resource_id_resources;
ALTER TABLE IF EXISTS ONLY public.reports DROP CONSTRAINT IF EXISTS fk_reports_object_id_objects;
ALTER TABLE IF EXISTS ONLY public.report_items DROP CONSTRAINT IF EXISTS fk_report_items_service_type_id_service_types;
ALTER TABLE IF EXISTS ONLY public.report_items DROP CONSTRAINT IF EXISTS fk_report_items_report_id_reports;
ALTER TABLE IF EXISTS ONLY public.plan_resources DROP CONSTRAINT IF EXISTS fk_plan_resources_resource_id_resources;
ALTER TABLE IF EXISTS ONLY public.plan_resources DROP CONSTRAINT IF EXISTS fk_plan_resources_plan_item_id_plan_items;
ALTER TABLE IF EXISTS ONLY public.plan_monthly DROP CONSTRAINT IF EXISTS fk_plan_monthly_plan_item_id_plan_items;
ALTER TABLE IF EXISTS ONLY public.plan_items DROP CONSTRAINT IF EXISTS fk_plan_items_service_type_id_service_types;
ALTER TABLE IF EXISTS ONLY public.plan_items DROP CONSTRAINT IF EXISTS fk_plan_items_plan_header_id_plan_headers;
ALTER TABLE IF EXISTS ONLY public.plan_headers DROP CONSTRAINT IF EXISTS fk_plan_headers_object_id_objects;
ALTER TABLE IF EXISTS ONLY public.fact_resources DROP CONSTRAINT IF EXISTS fk_fact_resources_resource_id_resources;
ALTER TABLE IF EXISTS ONLY public.fact_resources DROP CONSTRAINT IF EXISTS fk_fact_resources_fact_item_id_fact_items;
ALTER TABLE IF EXISTS ONLY public.fact_items DROP CONSTRAINT IF EXISTS fk_fact_items_service_type_id_service_types;
ALTER TABLE IF EXISTS ONLY public.fact_items DROP CONSTRAINT IF EXISTS fk_fact_items_plan_item_id_plan_items;
ALTER TABLE IF EXISTS ONLY public.fact_items DROP CONSTRAINT IF EXISTS fk_fact_items_fact_header_id_fact_headers;
ALTER TABLE IF EXISTS ONLY public.fact_headers DROP CONSTRAINT IF EXISTS fk_fact_headers_object_id_objects;
ALTER TABLE IF EXISTS ONLY public.audit_logs DROP CONSTRAINT IF EXISTS fk_audit_logs_user_id_users;
ALTER TABLE IF EXISTS ONLY public.acts DROP CONSTRAINT IF EXISTS fk_acts_fact_header_id_fact_headers;
ALTER TABLE IF EXISTS ONLY public.act_items DROP CONSTRAINT IF EXISTS fk_act_items_service_type_id_service_types;
ALTER TABLE IF EXISTS ONLY public.act_items DROP CONSTRAINT IF EXISTS fk_act_items_act_id_acts;
DROP INDEX IF EXISTS public.ix_users_username;
DROP INDEX IF EXISTS public.ix_users_email;
DROP INDEX IF EXISTS public.ix_units_code;
DROP INDEX IF EXISTS public.ix_service_rates_valid;
DROP INDEX IF EXISTS public.ix_reports_object_period;
DROP INDEX IF EXISTS public.ix_pricing_settings_valid;
DROP INDEX IF EXISTS public.ix_objects_type_active;
DROP INDEX IF EXISTS public.ix_fact_headers_status;
DROP INDEX IF EXISTS public.ix_fact_headers_period;
DROP INDEX IF EXISTS public.ix_acts_status;
ALTER TABLE IF EXISTS ONLY public.service_types DROP CONSTRAINT IF EXISTS uq_service_types_code;
ALTER TABLE IF EXISTS ONLY public.service_rates DROP CONSTRAINT IF EXISTS uq_service_rate_period;
ALTER TABLE IF EXISTS ONLY public.service_categories DROP CONSTRAINT IF EXISTS uq_service_categories_code;
ALTER TABLE IF EXISTS ONLY public.resources DROP CONSTRAINT IF EXISTS uq_resources_code;
ALTER TABLE IF EXISTS ONLY public.resource_rates DROP CONSTRAINT IF EXISTS uq_resource_rate_period;
ALTER TABLE IF EXISTS ONLY public.resource_norms DROP CONSTRAINT IF EXISTS uq_resource_norm_period;
ALTER TABLE IF EXISTS ONLY public.service_pricing_settings DROP CONSTRAINT IF EXISTS uq_pricing_settings_period;
ALTER TABLE IF EXISTS ONLY public.plan_monthly DROP CONSTRAINT IF EXISTS uq_plan_monthly_period;
ALTER TABLE IF EXISTS ONLY public.fact_headers DROP CONSTRAINT IF EXISTS uq_fact_header_period;
ALTER TABLE IF EXISTS ONLY public.acts DROP CONSTRAINT IF EXISTS uq_acts_act_number;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS pk_users;
ALTER TABLE IF EXISTS ONLY public.units DROP CONSTRAINT IF EXISTS pk_units;
ALTER TABLE IF EXISTS ONLY public.service_types DROP CONSTRAINT IF EXISTS pk_service_types;
ALTER TABLE IF EXISTS ONLY public.service_rates DROP CONSTRAINT IF EXISTS pk_service_rates;
ALTER TABLE IF EXISTS ONLY public.service_pricing_settings DROP CONSTRAINT IF EXISTS pk_service_pricing_settings;
ALTER TABLE IF EXISTS ONLY public.service_categories DROP CONSTRAINT IF EXISTS pk_service_categories;
ALTER TABLE IF EXISTS ONLY public.resources DROP CONSTRAINT IF EXISTS pk_resources;
ALTER TABLE IF EXISTS ONLY public.resource_rates DROP CONSTRAINT IF EXISTS pk_resource_rates;
ALTER TABLE IF EXISTS ONLY public.resource_norms DROP CONSTRAINT IF EXISTS pk_resource_norms;
ALTER TABLE IF EXISTS ONLY public.reports DROP CONSTRAINT IF EXISTS pk_reports;
ALTER TABLE IF EXISTS ONLY public.report_items DROP CONSTRAINT IF EXISTS pk_report_items;
ALTER TABLE IF EXISTS ONLY public.plan_resources DROP CONSTRAINT IF EXISTS pk_plan_resources;
ALTER TABLE IF EXISTS ONLY public.plan_monthly DROP CONSTRAINT IF EXISTS pk_plan_monthly;
ALTER TABLE IF EXISTS ONLY public.plan_items DROP CONSTRAINT IF EXISTS pk_plan_items;
ALTER TABLE IF EXISTS ONLY public.plan_headers DROP CONSTRAINT IF EXISTS pk_plan_headers;
ALTER TABLE IF EXISTS ONLY public.objects DROP CONSTRAINT IF EXISTS pk_objects;
ALTER TABLE IF EXISTS ONLY public.fact_resources DROP CONSTRAINT IF EXISTS pk_fact_resources;
ALTER TABLE IF EXISTS ONLY public.fact_items DROP CONSTRAINT IF EXISTS pk_fact_items;
ALTER TABLE IF EXISTS ONLY public.fact_headers DROP CONSTRAINT IF EXISTS pk_fact_headers;
ALTER TABLE IF EXISTS ONLY public.audit_logs DROP CONSTRAINT IF EXISTS pk_audit_logs;
ALTER TABLE IF EXISTS ONLY public.acts DROP CONSTRAINT IF EXISTS pk_acts;
ALTER TABLE IF EXISTS ONLY public.act_items DROP CONSTRAINT IF EXISTS pk_act_items;
ALTER TABLE IF EXISTS ONLY public.alembic_version DROP CONSTRAINT IF EXISTS alembic_version_pkc;
ALTER TABLE IF EXISTS public.users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.units ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.service_types ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.service_rates ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.service_pricing_settings ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.service_categories ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.resources ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.resource_rates ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.resource_norms ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.reports ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.report_items ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.plan_resources ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.plan_monthly ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.plan_items ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.plan_headers ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.objects ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.fact_resources ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.fact_items ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.fact_headers ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.audit_logs ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.acts ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.act_items ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE IF EXISTS public.users_id_seq;
DROP TABLE IF EXISTS public.users;
DROP SEQUENCE IF EXISTS public.units_id_seq;
DROP TABLE IF EXISTS public.units;
DROP SEQUENCE IF EXISTS public.service_types_id_seq;
DROP TABLE IF EXISTS public.service_types;
DROP SEQUENCE IF EXISTS public.service_rates_id_seq;
DROP TABLE IF EXISTS public.service_rates;
DROP SEQUENCE IF EXISTS public.service_pricing_settings_id_seq;
DROP TABLE IF EXISTS public.service_pricing_settings;
DROP SEQUENCE IF EXISTS public.service_categories_id_seq;
DROP TABLE IF EXISTS public.service_categories;
DROP SEQUENCE IF EXISTS public.resources_id_seq;
DROP TABLE IF EXISTS public.resources;
DROP SEQUENCE IF EXISTS public.resource_rates_id_seq;
DROP TABLE IF EXISTS public.resource_rates;
DROP SEQUENCE IF EXISTS public.resource_norms_id_seq;
DROP TABLE IF EXISTS public.resource_norms;
DROP SEQUENCE IF EXISTS public.reports_id_seq;
DROP TABLE IF EXISTS public.reports;
DROP SEQUENCE IF EXISTS public.report_items_id_seq;
DROP TABLE IF EXISTS public.report_items;
DROP SEQUENCE IF EXISTS public.plan_resources_id_seq;
DROP TABLE IF EXISTS public.plan_resources;
DROP SEQUENCE IF EXISTS public.plan_monthly_id_seq;
DROP TABLE IF EXISTS public.plan_monthly;
DROP SEQUENCE IF EXISTS public.plan_items_id_seq;
DROP TABLE IF EXISTS public.plan_items;
DROP SEQUENCE IF EXISTS public.plan_headers_id_seq;
DROP TABLE IF EXISTS public.plan_headers;
DROP SEQUENCE IF EXISTS public.objects_id_seq;
DROP TABLE IF EXISTS public.objects;
DROP SEQUENCE IF EXISTS public.fact_resources_id_seq;
DROP TABLE IF EXISTS public.fact_resources;
DROP SEQUENCE IF EXISTS public.fact_items_id_seq;
DROP TABLE IF EXISTS public.fact_items;
DROP SEQUENCE IF EXISTS public.fact_headers_id_seq;
DROP TABLE IF EXISTS public.fact_headers;
DROP SEQUENCE IF EXISTS public.audit_logs_id_seq;
DROP TABLE IF EXISTS public.audit_logs;
DROP TABLE IF EXISTS public.alembic_version;
DROP SEQUENCE IF EXISTS public.acts_id_seq;
DROP TABLE IF EXISTS public.acts;
DROP SEQUENCE IF EXISTS public.act_items_id_seq;
DROP TABLE IF EXISTS public.act_items;
DROP TYPE IF EXISTS public.planstatus;
DROP TYPE IF EXISTS public.objecttype;
DROP TYPE IF EXISTS public.factstatus;
DROP TYPE IF EXISTS public.actstatus;
--
-- Name: actstatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.actstatus AS ENUM (
    'draft',
    'submitted',
    'approved',
    'signed',
    'SUBMITTED',
    'DRAFT'
);


--
-- Name: factstatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.factstatus AS ENUM (
    'DRAFT',
    'SUBMITTED',
    'APPROVED',
    'REJECTED',
    'SIGNED'
);


--
-- Name: objecttype; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.objecttype AS ENUM (
    'MKD',
    'PARKING'
);


--
-- Name: planstatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.planstatus AS ENUM (
    'DRAFT',
    'APPROVED',
    'ARCHIVED',
    'submitted',
    'SUBMITTED'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: act_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.act_items (
    id integer NOT NULL,
    act_id integer NOT NULL,
    service_type_id integer NOT NULL,
    quantity numeric(15,4),
    unit_price numeric(15,4),
    total_amount numeric(15,2),
    frequency character varying(100)
);


--
-- Name: act_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.act_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: act_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.act_items_id_seq OWNED BY public.act_items.id;


--
-- Name: acts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.acts (
    id integer NOT NULL,
    act_number character varying(50) NOT NULL,
    act_date date NOT NULL,
    fact_header_id integer NOT NULL,
    total_amount numeric(15,2) NOT NULL,
    status public.actstatus DEFAULT 'draft'::public.actstatus NOT NULL,
    pdf_url character varying(500),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: acts_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.acts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: acts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.acts_id_seq OWNED BY public.acts.id;


--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_logs (
    id integer NOT NULL,
    user_id integer NOT NULL,
    action character varying(50) NOT NULL,
    resource_type character varying(50) NOT NULL,
    resource_id integer,
    old_values json,
    new_values json,
    ip_address character varying(45),
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: audit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.audit_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: audit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.audit_logs_id_seq OWNED BY public.audit_logs.id;


--
-- Name: fact_headers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fact_headers (
    id integer NOT NULL,
    object_id integer NOT NULL,
    year integer NOT NULL,
    month integer NOT NULL,
    status public.factstatus NOT NULL,
    created_by integer,
    created_at timestamp with time zone DEFAULT now(),
    approved_by integer,
    approved_at timestamp with time zone
);


--
-- Name: fact_headers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fact_headers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fact_headers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.fact_headers_id_seq OWNED BY public.fact_headers.id;


--
-- Name: fact_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fact_items (
    id integer NOT NULL,
    fact_header_id integer NOT NULL,
    plan_item_id integer,
    service_type_id integer NOT NULL,
    actual_quantity numeric(15,4) NOT NULL,
    unit_price numeric(15,4) NOT NULL,
    actual_amount numeric(15,2),
    executed_at date,
    executor character varying(200),
    notes text,
    attachments jsonb
);


--
-- Name: fact_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fact_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fact_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.fact_items_id_seq OWNED BY public.fact_items.id;


--
-- Name: fact_resources; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fact_resources (
    id integer NOT NULL,
    fact_item_id integer NOT NULL,
    resource_id integer NOT NULL,
    quantity numeric(15,6) NOT NULL,
    unit_price numeric(15,4),
    total_amount numeric(15,2)
);


--
-- Name: fact_resources_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fact_resources_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fact_resources_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.fact_resources_id_seq OWNED BY public.fact_resources.id;


--
-- Name: objects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.objects (
    id integer NOT NULL,
    name character varying(500) NOT NULL,
    type character varying(20) NOT NULL,
    address character varying(1000),
    area_sqm numeric(15,4),
    spaces_count integer,
    is_active boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    tariff_base character varying(20) DEFAULT 'area'::character varying NOT NULL
);


--
-- Name: objects_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.objects_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: objects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.objects_id_seq OWNED BY public.objects.id;


--
-- Name: plan_headers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.plan_headers (
    id integer NOT NULL,
    object_id integer NOT NULL,
    name character varying(200),
    status public.planstatus NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    start_year integer NOT NULL,
    start_month integer NOT NULL,
    period_months integer DEFAULT 12 NOT NULL
);


--
-- Name: plan_headers_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.plan_headers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: plan_headers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.plan_headers_id_seq OWNED BY public.plan_headers.id;


--
-- Name: plan_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.plan_items (
    id integer NOT NULL,
    plan_header_id integer NOT NULL,
    service_type_id integer NOT NULL,
    total_quantity numeric(15,4) NOT NULL,
    total_amount numeric(15,2) NOT NULL,
    frequency character varying(100),
    description text
);


--
-- Name: plan_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.plan_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: plan_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.plan_items_id_seq OWNED BY public.plan_items.id;


--
-- Name: plan_monthly; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.plan_monthly (
    id integer NOT NULL,
    plan_item_id integer NOT NULL,
    month integer NOT NULL,
    year integer NOT NULL,
    quantity numeric(15,4) NOT NULL,
    amount numeric(15,2),
    unit_price numeric(15,4) NOT NULL
);


--
-- Name: plan_monthly_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.plan_monthly_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: plan_monthly_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.plan_monthly_id_seq OWNED BY public.plan_monthly.id;


--
-- Name: plan_resources; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.plan_resources (
    id integer NOT NULL,
    plan_item_id integer NOT NULL,
    resource_id integer NOT NULL,
    required_quantity numeric(15,6) NOT NULL,
    unit_price numeric(15,4),
    total_amount numeric(15,2)
);


--
-- Name: plan_resources_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.plan_resources_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: plan_resources_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.plan_resources_id_seq OWNED BY public.plan_resources.id;


--
-- Name: report_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.report_items (
    id integer NOT NULL,
    report_id integer NOT NULL,
    service_type_id integer NOT NULL,
    service_name character varying(500) NOT NULL,
    unit_symbol character varying(20) NOT NULL,
    frequency character varying(100),
    category_name character varying(200),
    total_quantity numeric(15,4) NOT NULL,
    total_amount numeric(15,2) NOT NULL,
    acts_count integer NOT NULL
);


--
-- Name: report_items_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.report_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: report_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.report_items_id_seq OWNED BY public.report_items.id;


--
-- Name: reports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reports (
    id integer NOT NULL,
    object_id integer NOT NULL,
    start_month integer NOT NULL,
    start_year integer NOT NULL,
    end_month integer NOT NULL,
    end_year integer NOT NULL,
    name character varying(200),
    status character varying(20) NOT NULL,
    total_amount numeric(15,2) NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: reports_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.reports_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: reports_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.reports_id_seq OWNED BY public.reports.id;


--
-- Name: resource_norms; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.resource_norms (
    id integer NOT NULL,
    service_type_id integer NOT NULL,
    resource_id integer NOT NULL,
    quantity_per_unit numeric(15,6) NOT NULL,
    is_active boolean NOT NULL,
    valid_from date NOT NULL,
    valid_to date
);


--
-- Name: resource_norms_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.resource_norms_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: resource_norms_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.resource_norms_id_seq OWNED BY public.resource_norms.id;


--
-- Name: resource_rates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.resource_rates (
    id integer NOT NULL,
    resource_id integer NOT NULL,
    price_per_unit numeric(15,4) NOT NULL,
    valid_from date NOT NULL,
    valid_to date
);


--
-- Name: resource_rates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.resource_rates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: resource_rates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.resource_rates_id_seq OWNED BY public.resource_rates.id;


--
-- Name: resources; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.resources (
    id integer NOT NULL,
    code character varying(50) NOT NULL,
    name character varying(500) NOT NULL,
    unit character varying(50) NOT NULL,
    resource_type character varying(50) NOT NULL,
    is_active boolean NOT NULL
);


--
-- Name: resources_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.resources_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: resources_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.resources_id_seq OWNED BY public.resources.id;


--
-- Name: service_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.service_categories (
    id integer NOT NULL,
    code character varying(50) NOT NULL,
    name character varying(200) NOT NULL,
    sort_order integer NOT NULL,
    is_active boolean NOT NULL
);


--
-- Name: service_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.service_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: service_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.service_categories_id_seq OWNED BY public.service_categories.id;


--
-- Name: service_pricing_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.service_pricing_settings (
    id integer NOT NULL,
    object_id integer,
    service_type_id integer,
    overhead_percent numeric(5,2) NOT NULL,
    profit_percent numeric(5,2) NOT NULL,
    vat_percent numeric(5,2) NOT NULL,
    valid_from date NOT NULL,
    valid_to date
);


--
-- Name: COLUMN service_pricing_settings.object_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.service_pricing_settings.object_id IS 'NULL = для всех объектов';


--
-- Name: COLUMN service_pricing_settings.service_type_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.service_pricing_settings.service_type_id IS 'NULL = для всех услуг';


--
-- Name: COLUMN service_pricing_settings.overhead_percent; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.service_pricing_settings.overhead_percent IS 'Накладные расходы %';


--
-- Name: COLUMN service_pricing_settings.profit_percent; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.service_pricing_settings.profit_percent IS 'Норма прибыли %';


--
-- Name: COLUMN service_pricing_settings.vat_percent; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.service_pricing_settings.vat_percent IS 'НДС %';


--
-- Name: COLUMN service_pricing_settings.valid_to; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.service_pricing_settings.valid_to IS 'NULL = бессрочно';


--
-- Name: service_pricing_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.service_pricing_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: service_pricing_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.service_pricing_settings_id_seq OWNED BY public.service_pricing_settings.id;


--
-- Name: service_rates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.service_rates (
    id integer NOT NULL,
    service_type_id integer NOT NULL,
    price_per_unit numeric(15,4) NOT NULL,
    valid_from date NOT NULL,
    valid_to date,
    object_id integer
);


--
-- Name: service_rates_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.service_rates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: service_rates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.service_rates_id_seq OWNED BY public.service_rates.id;


--
-- Name: service_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.service_types (
    id integer NOT NULL,
    code character varying(50) NOT NULL,
    name character varying(500) NOT NULL,
    description character varying(2000),
    is_active boolean NOT NULL,
    unit_id integer NOT NULL,
    category_id integer NOT NULL,
    frequency character varying(100)
);


--
-- Name: service_types_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.service_types_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: service_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.service_types_id_seq OWNED BY public.service_types.id;


--
-- Name: units; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.units (
    id integer NOT NULL,
    code character varying(20) NOT NULL,
    name character varying(100) NOT NULL,
    symbol character varying(20) NOT NULL,
    is_active boolean NOT NULL
);


--
-- Name: units_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.units_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: units_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.units_id_seq OWNED BY public.units.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    email character varying(255) NOT NULL,
    username character varying(100) NOT NULL,
    full_name character varying(255) NOT NULL,
    hashed_password character varying(255) NOT NULL,
    role character varying(20) NOT NULL,
    is_active boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: COLUMN users.role; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.users.role IS 'admin/economist/master/viewer';


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: act_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_items ALTER COLUMN id SET DEFAULT nextval('public.act_items_id_seq'::regclass);


--
-- Name: acts id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.acts ALTER COLUMN id SET DEFAULT nextval('public.acts_id_seq'::regclass);


--
-- Name: audit_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs ALTER COLUMN id SET DEFAULT nextval('public.audit_logs_id_seq'::regclass);


--
-- Name: fact_headers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fact_headers ALTER COLUMN id SET DEFAULT nextval('public.fact_headers_id_seq'::regclass);


--
-- Name: fact_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fact_items ALTER COLUMN id SET DEFAULT nextval('public.fact_items_id_seq'::regclass);


--
-- Name: fact_resources id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fact_resources ALTER COLUMN id SET DEFAULT nextval('public.fact_resources_id_seq'::regclass);


--
-- Name: objects id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.objects ALTER COLUMN id SET DEFAULT nextval('public.objects_id_seq'::regclass);


--
-- Name: plan_headers id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plan_headers ALTER COLUMN id SET DEFAULT nextval('public.plan_headers_id_seq'::regclass);


--
-- Name: plan_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plan_items ALTER COLUMN id SET DEFAULT nextval('public.plan_items_id_seq'::regclass);


--
-- Name: plan_monthly id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plan_monthly ALTER COLUMN id SET DEFAULT nextval('public.plan_monthly_id_seq'::regclass);


--
-- Name: plan_resources id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plan_resources ALTER COLUMN id SET DEFAULT nextval('public.plan_resources_id_seq'::regclass);


--
-- Name: report_items id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report_items ALTER COLUMN id SET DEFAULT nextval('public.report_items_id_seq'::regclass);


--
-- Name: reports id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reports ALTER COLUMN id SET DEFAULT nextval('public.reports_id_seq'::regclass);


--
-- Name: resource_norms id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_norms ALTER COLUMN id SET DEFAULT nextval('public.resource_norms_id_seq'::regclass);


--
-- Name: resource_rates id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_rates ALTER COLUMN id SET DEFAULT nextval('public.resource_rates_id_seq'::regclass);


--
-- Name: resources id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resources ALTER COLUMN id SET DEFAULT nextval('public.resources_id_seq'::regclass);


--
-- Name: service_categories id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_categories ALTER COLUMN id SET DEFAULT nextval('public.service_categories_id_seq'::regclass);


--
-- Name: service_pricing_settings id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_pricing_settings ALTER COLUMN id SET DEFAULT nextval('public.service_pricing_settings_id_seq'::regclass);


--
-- Name: service_rates id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_rates ALTER COLUMN id SET DEFAULT nextval('public.service_rates_id_seq'::regclass);


--
-- Name: service_types id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_types ALTER COLUMN id SET DEFAULT nextval('public.service_types_id_seq'::regclass);


--
-- Name: units id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.units ALTER COLUMN id SET DEFAULT nextval('public.units_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: act_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.act_items (id, act_id, service_type_id, quantity, unit_price, total_amount, frequency) FROM stdin;
\.


--
-- Data for Name: acts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.acts (id, act_number, act_date, fact_header_id, total_amount, status, pdf_url, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alembic_version (version_num) FROM stdin;
9f49d804eb1e
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_logs (id, user_id, action, resource_type, resource_id, old_values, new_values, ip_address, created_at) FROM stdin;
1	1	UPDATE	OBJECT	3	{"name": "\\u041b\\u0435\\u043d\\u0438\\u043d\\u0430 1", "type": "\\u041f\\u0430\\u0440\\u043a\\u0438\\u043d\\u0433", "area_sqm": "1100.0000", "spaces_count": null, "tariff_base": "area"}	{"name": "\\u041b\\u0435\\u043d\\u0438\\u043d\\u0430 1", "type": "\\u041f\\u0430\\u0440\\u043a\\u0438\\u043d\\u0433", "address": "\\u0422\\u044e\\u043c\\u0435\\u043d\\u044c", "area_sqm": 1150.0, "spaces_count": null, "tariff_base": "area", "is_active": true}	127.0.0.1	2026-10-03 17:28:28.50368+00
2	1	DELETE	OBJECT	5	{"name": "\\u041b\\u0435\\u043d\\u0438\\u043d\\u0430 2", "type": "\\u041c\\u041a\\u0414"}	null	127.0.0.1	2026-10-03 17:56:23.064246+00
3	1	UPDATE	USER	5	{"username": "CC", "email": "ccc@mail.ru", "role": "master", "full_name": "CCC", "is_active": true}	{"username": "CC", "email": "ccc@mail.ru", "role": "master", "full_name": "CCCC", "is_active": true}	127.0.0.1	2026-10-03 17:59:42.427493+00
4	1	CREATE	PLAN	2	null	{"name": "1", "object_id": 3, "start_year": 2026, "start_month": 1, "period_months": 12}	127.0.0.1	2026-10-03 18:25:01.140646+00
5	1	CREATE	FACT	1	null	{"object_id": 3, "year": 2026, "month": 10}	127.0.0.1	2026-10-03 18:38:00.53286+00
6	1	CREATE	UNIT	2	null	{"code": "\\u0428\\u0422", "name": "\\u0428\\u0442\\u0443\\u043a\\u0430", "symbol": "\\u0448\\u0442"}	127.0.0.1	2026-10-03 18:38:34.84697+00
7	1	CREATE	REPORT	1	null	{"object_id": 3, "start_year": 2026, "end_year": 2026}	127.0.0.1	2026-10-03 18:41:12.133774+00
8	1	UPDATE	USER	5	{"username": "CC", "email": "ccc@mail.ru", "role": "master", "full_name": "CCCC", "is_active": true}	{"username": "CC", "email": "ccc@mail.ru", "role": "master", "full_name": "CCC", "is_active": true}	127.0.0.1	2026-10-03 18:41:36.243679+00
9	1	CREATE	PLAN	3	null	{"name": "1", "object_id": 2, "start_year": 2026, "start_month": 2, "period_months": 12, "status": "DRAFT"}	127.0.0.1	2026-10-05 16:52:36.629169+00
\.


--
-- Data for Name: fact_headers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fact_headers (id, object_id, year, month, status, created_by, created_at, approved_by, approved_at) FROM stdin;
1	3	2026	10	DRAFT	\N	2026-10-03 18:38:00.48591+00	\N	\N
\.


--
-- Data for Name: fact_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fact_items (id, fact_header_id, plan_item_id, service_type_id, actual_quantity, unit_price, actual_amount, executed_at, executor, notes, attachments) FROM stdin;
\.


--
-- Data for Name: fact_resources; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fact_resources (id, fact_item_id, resource_id, quantity, unit_price, total_amount) FROM stdin;
\.


--
-- Data for Name: objects; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.objects (id, name, type, address, area_sqm, spaces_count, is_active, created_at, updated_at, tariff_base) FROM stdin;
2	Малыгина 1	Паркинг	\N	\N	120	t	2026-10-02 19:16:10.987161+00	2026-10-02 19:16:25.450054+00	spaces
4	Малыгина 4	Паркинг	Тюмень	\N	120	t	2026-10-03 16:59:42.874041+00	2026-10-03 16:59:42.874041+00	spaces
3	Ленина 1	Паркинг	Тюмень	1150.0000	\N	t	2026-10-03 16:57:03.02124+00	2026-10-03 17:28:28.479791+00	area
\.


--
-- Data for Name: plan_headers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.plan_headers (id, object_id, name, status, created_at, start_year, start_month, period_months) FROM stdin;
2	3	1	DRAFT	2026-10-03 18:25:01.095667+00	2026	1	12
3	2	1	DRAFT	2026-10-05 16:52:36.607167+00	2026	2	12
\.


--
-- Data for Name: plan_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.plan_items (id, plan_header_id, service_type_id, total_quantity, total_amount, frequency, description) FROM stdin;
\.


--
-- Data for Name: plan_monthly; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.plan_monthly (id, plan_item_id, month, year, quantity, amount, unit_price) FROM stdin;
\.


--
-- Data for Name: plan_resources; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.plan_resources (id, plan_item_id, resource_id, required_quantity, unit_price, total_amount) FROM stdin;
\.


--
-- Data for Name: report_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.report_items (id, report_id, service_type_id, service_name, unit_symbol, frequency, category_name, total_quantity, total_amount, acts_count) FROM stdin;
\.


--
-- Data for Name: reports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.reports (id, object_id, start_month, start_year, end_month, end_year, name, status, total_amount, notes, created_at, updated_at) FROM stdin;
1	3	1	2026	12	2026	\N	draft	0.00	\N	2026-10-03 18:41:12.100048+00	2026-10-03 18:41:12.100048+00
\.


--
-- Data for Name: resource_norms; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.resource_norms (id, service_type_id, resource_id, quantity_per_unit, is_active, valid_from, valid_to) FROM stdin;
\.


--
-- Data for Name: resource_rates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.resource_rates (id, resource_id, price_per_unit, valid_from, valid_to) FROM stdin;
\.


--
-- Data for Name: resources; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.resources (id, code, name, unit, resource_type, is_active) FROM stdin;
\.


--
-- Data for Name: service_categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.service_categories (id, code, name, sort_order, is_active) FROM stdin;
1	UPR	Управление	1	t
\.


--
-- Data for Name: service_pricing_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.service_pricing_settings (id, object_id, service_type_id, overhead_percent, profit_percent, vat_percent, valid_from, valid_to) FROM stdin;
\.


--
-- Data for Name: service_rates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.service_rates (id, service_type_id, price_per_unit, valid_from, valid_to, object_id) FROM stdin;
\.


--
-- Data for Name: service_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.service_types (id, code, name, description, is_active, unit_id, category_id, frequency) FROM stdin;
1	UPR-1	Подготовка квитанций	\N	t	1	1	ежемесячно
\.


--
-- Data for Name: units; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.units (id, code, name, symbol, is_active) FROM stdin;
1	М2	Квадратный метр	м2	t
2	ШТ	Штука	шт	t
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, email, username, full_name, hashed_password, role, is_active, created_at, updated_at) FROM stdin;
1	maksim.antipkin@gmail.com	MA	Maksim	$2b$12$sUdbpc6ejxA3/XpdfMMi9.cwG1738gr6Vio4ttLOSBGWudN.QOp2a	admin	t	2026-09-30 16:40:13.307183+00	2026-09-30 16:40:13.307183+00
3	aaa@mail.ru	AA	AAA	$2b$12$PlOX0JuQavtWOj3dg8XobusaGU9oy6U8WGTfNL2r9muqJQyCaCX0O	viewer	t	2026-10-02 16:50:40.818608+00	2026-10-02 16:50:40.818608+00
4	bbb@mail.ru	BB	BBB	$2b$12$t2T9MJfdqck9Tv5KIpt0BuDj.zUEqfR/NLDZIdN7u2jfwOJ3mqvFa	economist	t	2026-10-02 17:14:03.719066+00	2026-10-02 17:14:13.669153+00
5	ccc@mail.ru	CC	CCC	$2b$12$eLjkxAeeXUL31vcKJVA/NefKmKEiedjMynLjy9PaX0JIRNsk9WP76	master	t	2026-10-02 17:14:36.153102+00	2026-10-03 18:41:36.213009+00
\.


--
-- Name: act_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.act_items_id_seq', 1, false);


--
-- Name: acts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.acts_id_seq', 1, false);


--
-- Name: audit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.audit_logs_id_seq', 9, true);


--
-- Name: fact_headers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.fact_headers_id_seq', 1, true);


--
-- Name: fact_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.fact_items_id_seq', 1, false);


--
-- Name: fact_resources_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.fact_resources_id_seq', 1, false);


--
-- Name: objects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.objects_id_seq', 5, true);


--
-- Name: plan_headers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.plan_headers_id_seq', 3, true);


--
-- Name: plan_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.plan_items_id_seq', 1, false);


--
-- Name: plan_monthly_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.plan_monthly_id_seq', 1, false);


--
-- Name: plan_resources_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.plan_resources_id_seq', 1, false);


--
-- Name: report_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.report_items_id_seq', 1, false);


--
-- Name: reports_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.reports_id_seq', 1, true);


--
-- Name: resource_norms_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.resource_norms_id_seq', 1, false);


--
-- Name: resource_rates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.resource_rates_id_seq', 1, false);


--
-- Name: resources_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.resources_id_seq', 1, false);


--
-- Name: service_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.service_categories_id_seq', 1, true);


--
-- Name: service_pricing_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.service_pricing_settings_id_seq', 1, false);


--
-- Name: service_rates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.service_rates_id_seq', 1, false);


--
-- Name: service_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.service_types_id_seq', 1, true);


--
-- Name: units_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.units_id_seq', 2, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 5, true);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: act_items pk_act_items; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_items
    ADD CONSTRAINT pk_act_items PRIMARY KEY (id);


--
-- Name: acts pk_acts; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.acts
    ADD CONSTRAINT pk_acts PRIMARY KEY (id);


--
-- Name: audit_logs pk_audit_logs; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT pk_audit_logs PRIMARY KEY (id);


--
-- Name: fact_headers pk_fact_headers; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fact_headers
    ADD CONSTRAINT pk_fact_headers PRIMARY KEY (id);


--
-- Name: fact_items pk_fact_items; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fact_items
    ADD CONSTRAINT pk_fact_items PRIMARY KEY (id);


--
-- Name: fact_resources pk_fact_resources; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fact_resources
    ADD CONSTRAINT pk_fact_resources PRIMARY KEY (id);


--
-- Name: objects pk_objects; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.objects
    ADD CONSTRAINT pk_objects PRIMARY KEY (id);


--
-- Name: plan_headers pk_plan_headers; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plan_headers
    ADD CONSTRAINT pk_plan_headers PRIMARY KEY (id);


--
-- Name: plan_items pk_plan_items; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plan_items
    ADD CONSTRAINT pk_plan_items PRIMARY KEY (id);


--
-- Name: plan_monthly pk_plan_monthly; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plan_monthly
    ADD CONSTRAINT pk_plan_monthly PRIMARY KEY (id);


--
-- Name: plan_resources pk_plan_resources; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plan_resources
    ADD CONSTRAINT pk_plan_resources PRIMARY KEY (id);


--
-- Name: report_items pk_report_items; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report_items
    ADD CONSTRAINT pk_report_items PRIMARY KEY (id);


--
-- Name: reports pk_reports; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reports
    ADD CONSTRAINT pk_reports PRIMARY KEY (id);


--
-- Name: resource_norms pk_resource_norms; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_norms
    ADD CONSTRAINT pk_resource_norms PRIMARY KEY (id);


--
-- Name: resource_rates pk_resource_rates; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_rates
    ADD CONSTRAINT pk_resource_rates PRIMARY KEY (id);


--
-- Name: resources pk_resources; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resources
    ADD CONSTRAINT pk_resources PRIMARY KEY (id);


--
-- Name: service_categories pk_service_categories; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_categories
    ADD CONSTRAINT pk_service_categories PRIMARY KEY (id);


--
-- Name: service_pricing_settings pk_service_pricing_settings; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_pricing_settings
    ADD CONSTRAINT pk_service_pricing_settings PRIMARY KEY (id);


--
-- Name: service_rates pk_service_rates; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_rates
    ADD CONSTRAINT pk_service_rates PRIMARY KEY (id);


--
-- Name: service_types pk_service_types; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_types
    ADD CONSTRAINT pk_service_types PRIMARY KEY (id);


--
-- Name: units pk_units; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.units
    ADD CONSTRAINT pk_units PRIMARY KEY (id);


--
-- Name: users pk_users; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT pk_users PRIMARY KEY (id);


--
-- Name: acts uq_acts_act_number; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.acts
    ADD CONSTRAINT uq_acts_act_number UNIQUE (act_number);


--
-- Name: fact_headers uq_fact_header_period; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fact_headers
    ADD CONSTRAINT uq_fact_header_period UNIQUE (object_id, year, month);


--
-- Name: plan_monthly uq_plan_monthly_period; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plan_monthly
    ADD CONSTRAINT uq_plan_monthly_period UNIQUE (plan_item_id, month, year);


--
-- Name: service_pricing_settings uq_pricing_settings_period; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_pricing_settings
    ADD CONSTRAINT uq_pricing_settings_period UNIQUE (object_id, service_type_id, valid_from);


--
-- Name: resource_norms uq_resource_norm_period; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_norms
    ADD CONSTRAINT uq_resource_norm_period UNIQUE (service_type_id, resource_id, valid_from);


--
-- Name: resource_rates uq_resource_rate_period; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_rates
    ADD CONSTRAINT uq_resource_rate_period UNIQUE (resource_id, valid_from);


--
-- Name: resources uq_resources_code; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resources
    ADD CONSTRAINT uq_resources_code UNIQUE (code);


--
-- Name: service_categories uq_service_categories_code; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_categories
    ADD CONSTRAINT uq_service_categories_code UNIQUE (code);


--
-- Name: service_rates uq_service_rate_period; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_rates
    ADD CONSTRAINT uq_service_rate_period UNIQUE (object_id, service_type_id, valid_from);


--
-- Name: service_types uq_service_types_code; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_types
    ADD CONSTRAINT uq_service_types_code UNIQUE (code);


--
-- Name: ix_acts_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_acts_status ON public.acts USING btree (status);


--
-- Name: ix_fact_headers_period; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_fact_headers_period ON public.fact_headers USING btree (object_id, year, month);


--
-- Name: ix_fact_headers_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_fact_headers_status ON public.fact_headers USING btree (status);


--
-- Name: ix_objects_type_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_objects_type_active ON public.objects USING btree (type, is_active);


--
-- Name: ix_pricing_settings_valid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_pricing_settings_valid ON public.service_pricing_settings USING btree (object_id, service_type_id, valid_from);


--
-- Name: ix_reports_object_period; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_reports_object_period ON public.reports USING btree (object_id, start_year, start_month);


--
-- Name: ix_service_rates_valid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_service_rates_valid ON public.service_rates USING btree (object_id, service_type_id, valid_from);


--
-- Name: ix_units_code; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_units_code ON public.units USING btree (code);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: ix_users_username; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_users_username ON public.users USING btree (username);


--
-- Name: act_items fk_act_items_act_id_acts; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_items
    ADD CONSTRAINT fk_act_items_act_id_acts FOREIGN KEY (act_id) REFERENCES public.acts(id) ON DELETE CASCADE;


--
-- Name: act_items fk_act_items_service_type_id_service_types; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.act_items
    ADD CONSTRAINT fk_act_items_service_type_id_service_types FOREIGN KEY (service_type_id) REFERENCES public.service_types(id) ON DELETE RESTRICT;


--
-- Name: acts fk_acts_fact_header_id_fact_headers; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.acts
    ADD CONSTRAINT fk_acts_fact_header_id_fact_headers FOREIGN KEY (fact_header_id) REFERENCES public.fact_headers(id) ON DELETE CASCADE;


--
-- Name: audit_logs fk_audit_logs_user_id_users; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT fk_audit_logs_user_id_users FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: fact_headers fk_fact_headers_object_id_objects; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fact_headers
    ADD CONSTRAINT fk_fact_headers_object_id_objects FOREIGN KEY (object_id) REFERENCES public.objects(id) ON DELETE CASCADE;


--
-- Name: fact_items fk_fact_items_fact_header_id_fact_headers; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fact_items
    ADD CONSTRAINT fk_fact_items_fact_header_id_fact_headers FOREIGN KEY (fact_header_id) REFERENCES public.fact_headers(id) ON DELETE CASCADE;


--
-- Name: fact_items fk_fact_items_plan_item_id_plan_items; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fact_items
    ADD CONSTRAINT fk_fact_items_plan_item_id_plan_items FOREIGN KEY (plan_item_id) REFERENCES public.plan_items(id) ON DELETE SET NULL;


--
-- Name: fact_items fk_fact_items_service_type_id_service_types; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fact_items
    ADD CONSTRAINT fk_fact_items_service_type_id_service_types FOREIGN KEY (service_type_id) REFERENCES public.service_types(id) ON DELETE RESTRICT;


--
-- Name: fact_resources fk_fact_resources_fact_item_id_fact_items; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fact_resources
    ADD CONSTRAINT fk_fact_resources_fact_item_id_fact_items FOREIGN KEY (fact_item_id) REFERENCES public.fact_items(id) ON DELETE CASCADE;


--
-- Name: fact_resources fk_fact_resources_resource_id_resources; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fact_resources
    ADD CONSTRAINT fk_fact_resources_resource_id_resources FOREIGN KEY (resource_id) REFERENCES public.resources(id) ON DELETE RESTRICT;


--
-- Name: plan_headers fk_plan_headers_object_id_objects; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plan_headers
    ADD CONSTRAINT fk_plan_headers_object_id_objects FOREIGN KEY (object_id) REFERENCES public.objects(id) ON DELETE CASCADE;


--
-- Name: plan_items fk_plan_items_plan_header_id_plan_headers; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plan_items
    ADD CONSTRAINT fk_plan_items_plan_header_id_plan_headers FOREIGN KEY (plan_header_id) REFERENCES public.plan_headers(id) ON DELETE CASCADE;


--
-- Name: plan_items fk_plan_items_service_type_id_service_types; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plan_items
    ADD CONSTRAINT fk_plan_items_service_type_id_service_types FOREIGN KEY (service_type_id) REFERENCES public.service_types(id) ON DELETE RESTRICT;


--
-- Name: plan_monthly fk_plan_monthly_plan_item_id_plan_items; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plan_monthly
    ADD CONSTRAINT fk_plan_monthly_plan_item_id_plan_items FOREIGN KEY (plan_item_id) REFERENCES public.plan_items(id) ON DELETE CASCADE;


--
-- Name: plan_resources fk_plan_resources_plan_item_id_plan_items; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plan_resources
    ADD CONSTRAINT fk_plan_resources_plan_item_id_plan_items FOREIGN KEY (plan_item_id) REFERENCES public.plan_items(id) ON DELETE CASCADE;


--
-- Name: plan_resources fk_plan_resources_resource_id_resources; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plan_resources
    ADD CONSTRAINT fk_plan_resources_resource_id_resources FOREIGN KEY (resource_id) REFERENCES public.resources(id) ON DELETE RESTRICT;


--
-- Name: report_items fk_report_items_report_id_reports; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report_items
    ADD CONSTRAINT fk_report_items_report_id_reports FOREIGN KEY (report_id) REFERENCES public.reports(id) ON DELETE CASCADE;


--
-- Name: report_items fk_report_items_service_type_id_service_types; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report_items
    ADD CONSTRAINT fk_report_items_service_type_id_service_types FOREIGN KEY (service_type_id) REFERENCES public.service_types(id) ON DELETE RESTRICT;


--
-- Name: reports fk_reports_object_id_objects; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reports
    ADD CONSTRAINT fk_reports_object_id_objects FOREIGN KEY (object_id) REFERENCES public.objects(id) ON DELETE CASCADE;


--
-- Name: resource_norms fk_resource_norms_resource_id_resources; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_norms
    ADD CONSTRAINT fk_resource_norms_resource_id_resources FOREIGN KEY (resource_id) REFERENCES public.resources(id) ON DELETE CASCADE;


--
-- Name: resource_norms fk_resource_norms_service_type_id_service_types; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_norms
    ADD CONSTRAINT fk_resource_norms_service_type_id_service_types FOREIGN KEY (service_type_id) REFERENCES public.service_types(id) ON DELETE CASCADE;


--
-- Name: resource_rates fk_resource_rates_resource_id_resources; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resource_rates
    ADD CONSTRAINT fk_resource_rates_resource_id_resources FOREIGN KEY (resource_id) REFERENCES public.resources(id) ON DELETE CASCADE;


--
-- Name: service_pricing_settings fk_service_pricing_settings_object_id_objects; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_pricing_settings
    ADD CONSTRAINT fk_service_pricing_settings_object_id_objects FOREIGN KEY (object_id) REFERENCES public.objects(id) ON DELETE CASCADE;


--
-- Name: service_pricing_settings fk_service_pricing_settings_service_type_id_service_types; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_pricing_settings
    ADD CONSTRAINT fk_service_pricing_settings_service_type_id_service_types FOREIGN KEY (service_type_id) REFERENCES public.service_types(id) ON DELETE CASCADE;


--
-- Name: service_rates fk_service_rates_object_id_objects; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_rates
    ADD CONSTRAINT fk_service_rates_object_id_objects FOREIGN KEY (object_id) REFERENCES public.objects(id) ON DELETE CASCADE;


--
-- Name: service_rates fk_service_rates_service_type_id_service_types; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_rates
    ADD CONSTRAINT fk_service_rates_service_type_id_service_types FOREIGN KEY (service_type_id) REFERENCES public.service_types(id) ON DELETE CASCADE;


--
-- Name: service_types fk_service_types_category_id_service_categories; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_types
    ADD CONSTRAINT fk_service_types_category_id_service_categories FOREIGN KEY (category_id) REFERENCES public.service_categories(id) ON DELETE RESTRICT;


--
-- Name: service_types fk_service_types_unit_id_units; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_types
    ADD CONSTRAINT fk_service_types_unit_id_units FOREIGN KEY (unit_id) REFERENCES public.units(id) ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

\unrestrict QzQomyhycbrzOubvcZNEOfP88EYY6lP8ibwTAHEy7NS4oj0JchWIauCyEzZIo1Z

